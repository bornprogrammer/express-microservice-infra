

export default class UserStatus {
  static ACTIVE = "active";

  static INACTIVE = "inactive";

  static SUSPENDED = "suspended";
}