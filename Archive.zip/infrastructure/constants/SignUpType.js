
export default class SignUpType {
  static GOOGLE = "google";

  static LINKED_IN = "linkedin";

  static INCRUITER = "incruiter";
}