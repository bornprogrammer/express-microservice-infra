
export default class HttpMethod {
  static POST = "POST";

  static GET = "GET";

  static PUT = "PUT";

  static DELETE = "DELETE";

  static PATCH = "PATCH";
}