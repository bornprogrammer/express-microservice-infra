

export default class UserType {
  static EMPLOYER = "employer";

  static INTERVIEWER = "interviewer";

  static RECRUITER = "recruiter";

  static SUBEMPLOYER = "subemployer";
}