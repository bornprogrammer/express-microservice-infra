

export default class BaseService {

}
