
import BaseService from "./BaseService.js";

class EmployerService extends BaseService {

}

export default new EmployerService();